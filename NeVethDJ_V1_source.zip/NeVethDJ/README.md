# NeVeth DJ — V1

Aplicación Android DJ de dos decks, creada como base funcional.

## Incluye en V1
- Dos reproductores independientes con Media3/ExoPlayer.
- Carga de archivos de audio desde el teléfono.
- Play/Pause.
- Seek/barra de posición.
- Volumen por deck.
- Pitch/velocidad por deck.
- Crossfader.
- Master volume.
- Botón SYNC básico.
- Interfaz morado/blanco sobre fondo oscuro.
- Vinilos visuales.
- Espectro visual grande animado en la parte superior.
- Paneles de FX/EQ/LOOP/HOT CUES/SAMPLER como base de la siguiente etapa.

## Importante
El EQ, FX, sampler, scratch, hot cues y waveform real todavía son módulos de V2. Los controles visuales ya están preparados para conectarlos al motor de audio.

## Abrir el proyecto
1. Instala Android Studio reciente.
2. Abre la carpeta `NeVethDJ`.
3. Espera a que Gradle sincronice.
4. Conecta un teléfono Android o crea un emulador.
5. Ejecuta `app`.
6. Para generar APK: Build > Build APK(s).

## Próximas mejoras recomendadas
1. Waveform real de cada canción.
2. BPM/beat detection real.
3. EQ de 3 bandas mediante AudioProcessor.
4. FX con cadena de audio.
5. Hot Cues y loops.
6. Scratch usando gestos sobre el vinilo.
7. Sampler con pads.
8. Grabador de mezcla.
9. Persistencia de biblioteca y playlists.
10. Branding final con el logo NeVeth proporcionado por el usuario.
