package com.neveth.dj

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import kotlin.math.abs
import kotlin.math.sin

private val Bg = Color(0xFF09070F)
private val Panel = Color(0xFF14111D)
private val Panel2 = Color(0xFF1B1726)
private val Purple = Color(0xFF9B5CFF)
private val Purple2 = Color(0xFFD9C3FF)
private val White = Color(0xFFF7F3FF)
private val Muted = Color(0xFF8D8799)

data class DeckState(
    val title: String = "Cargar canción",
    val uri: Uri? = null,
    val playing: Boolean = false,
    val position: Long = 0L,
    val duration: Long = 1L,
    val volume: Float = 1f,
    val speed: Float = 1f
)

class MainActivity : ComponentActivity() {
    private lateinit var left: ExoPlayer
    private lateinit var right: ExoPlayer

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        left = ExoPlayer.Builder(this).build()
        right = ExoPlayer.Builder(this).build()

        setContent {
            NeVethApp(left, right)
        }
    }

    override fun onDestroy() {
        left.release()
        right.release()
        super.onDestroy()
    }
}

@Composable
fun NeVethApp(left: ExoPlayer, right: ExoPlayer) {
    var leftState by remember { mutableStateOf(DeckState()) }
    var rightState by remember { mutableStateOf(DeckState()) }
    var crossfader by remember { mutableFloatStateOf(0.5f) }
    var master by remember { mutableFloatStateOf(1f) }
    var selectedDeck by remember { mutableIntStateOf(0) }

    val openLeft = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        uri ?: return@rememberLauncherForActivityResult
        left.setMediaItem(MediaItem.fromUri(uri))
        left.prepare()
        leftState = leftState.copy(uri = uri, title = "Pista A", duration = 1L)
    }
    val openRight = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        uri ?: return@rememberLauncherForActivityResult
        right.setMediaItem(MediaItem.fromUri(uri))
        right.prepare()
        rightState = rightState.copy(uri = uri, title = "Pista B", duration = 1L)
    }

    LaunchedEffect(Unit) {
        while (true) {
            kotlinx.coroutines.delay(150)
            leftState = leftState.copy(
                playing = left.isPlaying,
                position = left.currentPosition.coerceAtLeast(0),
                duration = left.duration.takeIf { it > 0 } ?: 1L
            )
            rightState = rightState.copy(
                playing = right.isPlaying,
                position = right.currentPosition.coerceAtLeast(0),
                duration = right.duration.takeIf { it > 0 } ?: 1L
            )
        }
    }

    LaunchedEffect(crossfader, master, leftState.volume, rightState.volume) {
        val leftGain = (1f - crossfader) * leftState.volume * master
        val rightGain = crossfader * rightState.volume * master
        left.volume = leftGain.coerceIn(0f, 1f)
        right.volume = rightGain.coerceIn(0f, 1f)
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Bg,
            surface = Panel,
            primary = Purple,
            onPrimary = Color.Black,
            onBackground = White,
            onSurface = White
        )
    ) {
        Surface(modifier = Modifier.fillMaxSize(), color = Bg) {
            Column(Modifier.fillMaxSize()) {
                TopBar()

                // Large audio/spectrum area
                SpectrumArea(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(150.dp)
                )

                Row(
                    Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .padding(horizontal = 10.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Deck(
                        modifier = Modifier.weight(1f),
                        label = "A",
                        state = leftState,
                        onLoad = { selectedDeck = 0; openLeft.launch(arrayOf("audio/*")) },
                        onPlay = {
                            if (left.isPlaying) left.pause() else left.play()
                        },
                        onSeek = { p -> left.seekTo(p) },
                        onVolume = { leftState = leftState.copy(volume = it) },
                        onSpeed = { leftState = leftState.copy(speed = it); left.setPlaybackSpeed(it) }
                    )

                    Mixer(
                        modifier = Modifier.width(150.dp),
                        crossfader = crossfader,
                        onCrossfader = { crossfader = it },
                        master = master,
                        onMaster = { master = it },
                        onSync = {
                            val target = maxOf(left.currentPosition, right.currentPosition)
                            if (leftState.uri != null) left.seekTo(target)
                            if (rightState.uri != null) right.seekTo(target)
                        }
                    )

                    Deck(
                        modifier = Modifier.weight(1f),
                        label = "B",
                        state = rightState,
                        onLoad = { selectedDeck = 1; openRight.launch(arrayOf("audio/*")) },
                        onPlay = {
                            if (right.isPlaying) right.pause() else right.play()
                        },
                        onSeek = { p -> right.seekTo(p) },
                        onVolume = { rightState = rightState.copy(volume = it) },
                        onSpeed = { rightState = rightState.copy(speed = it); right.setPlaybackSpeed(it) }
                    )
                }

                BottomTools()
            }
        }
    }
}

@Composable
private fun TopBar() {
    Row(
        Modifier
            .fillMaxWidth()
            .height(58.dp)
            .background(Panel)
            .padding(horizontal = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("NEVETH", fontSize = 23.sp, fontWeight = FontWeight.Bold, color = White)
        Spacer(Modifier.weight(1f))
        Text("DJ", color = Purple, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        Spacer(Modifier.width(12.dp))
        Button(
            onClick = {},
            colors = ButtonDefaults.buttonColors(containerColor = Purple),
            shape = RoundedCornerShape(12.dp)
        ) { Text("MENU") }
    }
}

@Composable
private fun SpectrumArea(modifier: Modifier) {
    var phase by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(Unit) {
        while (true) {
            kotlinx.coroutines.delay(30)
            phase += 0.08f
        }
    }
    Canvas(modifier.background(Color(0xFF0D0A14))) {
        val bars = 100
        val barW = size.width / bars
        for (i in 0 until bars) {
            val wave = abs(sin(i * 0.28f + phase)) * 0.45f +
                    abs(sin(i * 0.071f + phase * 0.6f)) * 0.55f
            val h = size.height * (0.12f + wave * 0.72f)
            drawLine(
                color = Purple2.copy(alpha = 0.25f + wave * 0.75f),
                start = Offset(i * barW, size.height / 2f - h / 2f),
                end = Offset(i * barW, size.height / 2f + h / 2f),
                strokeWidth = maxOf(2f, barW * 0.55f),
                cap = StrokeCap.Round
            )
        }
        drawLine(
            color = White,
            start = Offset(size.width / 2f, 0f),
            end = Offset(size.width / 2f, size.height),
            strokeWidth = 2f
        )
    }
}

@Composable
private fun Deck(
    modifier: Modifier,
    label: String,
    state: DeckState,
    onLoad: () -> Unit,
    onPlay: () -> Unit,
    onSeek: (Long) -> Unit,
    onVolume: (Float) -> Unit,
    onSpeed: (Float) -> Unit
) {
    Column(
        modifier
            .clip(RoundedCornerShape(14.dp))
            .background(Panel)
            .border(1.dp, Color.White.copy(alpha = .05f), RoundedCornerShape(14.dp))
            .padding(10.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("DECK $label", color = Purple, fontWeight = FontWeight.Bold)
                Text(state.title, color = White, fontSize = 13.sp, maxLines = 1)
            }
            Text("BPM 126", color = Muted, fontSize = 12.sp)
        }

        Vinyl(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(vertical = 8.dp)
        )

        Text(
            formatTime(state.position),
            color = White,
            fontSize = 12.sp
        )
        Slider(
            value = state.position.toFloat().coerceIn(0f, state.duration.toFloat()),
            onValueChange = { onSeek(it.toLong()) },
            valueRange = 0f..state.duration.toFloat(),
            colors = SliderDefaults.colors(thumbColor = Purple, activeTrackColor = Purple)
        )

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            OutlinedButton(
                modifier = Modifier.weight(1f),
                onClick = onLoad
            ) { Text("CARGAR", fontSize = 11.sp) }
            Button(
                modifier = Modifier.weight(1f),
                onClick = onPlay,
                colors = ButtonDefaults.buttonColors(containerColor = Purple)
            ) { Text(if (state.playing) "PAUSA" else "PLAY", fontSize = 11.sp) }
        }

        Text("VOL", color = Muted, fontSize = 10.sp)
        Slider(
            value = state.volume,
            onValueChange = onVolume,
            colors = SliderDefaults.colors(thumbColor = Purple, activeTrackColor = Purple)
        )

        Text("PITCH  ${(state.speed - 1f) * 100f}%".replace(".0%", "%"), color = Muted, fontSize = 10.sp)
        Slider(
            value = state.speed,
            onValueChange = onSpeed,
            valueRange = 0.8f..1.2f,
            colors = SliderDefaults.colors(thumbColor = Purple, activeTrackColor = Purple)
        )
    }
}

@Composable
private fun Vinyl(modifier: Modifier) {
    Canvas(modifier) {
        val r = minOf(size.width, size.height) * .44f
        val c = Offset(size.width / 2f, size.height / 2f)
        drawCircle(Color(0xFF101015), r, c)
        for (i in 1..18) {
            drawCircle(
                Color(0xFF27232D),
                r * (i / 19f),
                c,
                style = androidx.compose.ui.graphics.drawscope.Stroke(1f)
            )
        }
        drawCircle(Purple.copy(alpha = .22f), r * .30f, c)
        drawCircle(Color(0xFF15121B), r * .25f, c)
        drawCircle(White.copy(alpha = .8f), r * .13f, c, style = androidx.compose.ui.graphics.drawscope.Stroke(2f))
        drawCircle(Purple, r * .025f, c)
    }
}

@Composable
private fun Mixer(
    modifier: Modifier,
    crossfader: Float,
    onCrossfader: (Float) -> Unit,
    master: Float,
    onMaster: (Float) -> Unit,
    onSync: () -> Unit
) {
    Column(
        modifier
            .fillMaxHeight()
            .clip(RoundedCornerShape(14.dp))
            .background(Panel2)
            .padding(10.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("MIXER", color = Purple, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(10.dp))
        Text("MASTER", color = Muted, fontSize = 10.sp)
        Slider(
            value = master,
            onValueChange = onMaster,
            modifier = Modifier.height(150.dp),
            colors = SliderDefaults.colors(thumbColor = Purple, activeTrackColor = Purple)
        )
        Spacer(Modifier.height(10.dp))
        Text("EQ", color = White, fontWeight = FontWeight.Bold)
        Text("HIGH", color = Muted, fontSize = 10.sp)
        Slider(value = .5f, onValueChange = {}, enabled = false)
        Text("MID", color = Muted, fontSize = 10.sp)
        Slider(value = .5f, onValueChange = {}, enabled = false)
        Text("LOW", color = Muted, fontSize = 10.sp)
        Slider(value = .5f, onValueChange = {}, enabled = false)
        Spacer(Modifier.height(8.dp))
        Button(
            onClick = onSync,
            colors = ButtonDefaults.buttonColors(containerColor = Purple),
            modifier = Modifier.fillMaxWidth()
        ) { Text("SYNC") }
        Spacer(Modifier.weight(1f))
        Text("CROSSFADER", color = Muted, fontSize = 10.sp)
        Slider(
            value = crossfader,
            onValueChange = onCrossfader,
            colors = SliderDefaults.colors(thumbColor = Purple, activeTrackColor = Purple)
        )
    }
}

@Composable
private fun BottomTools() {
    Row(
        Modifier
            .fillMaxWidth()
            .height(86.dp)
            .background(Panel)
            .padding(8.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        ToolButton("FX")
        ToolButton("LOOP")
        ToolButton("EQ")
        ToolButton("HOT CUES")
        ToolButton("SAMPLER")
        Spacer(Modifier.weight(1f))
        Text("V1.0", color = Muted, fontSize = 11.sp)
    }
}

@Composable
private fun ToolButton(text: String) {
    OutlinedButton(
        onClick = {},
        modifier = Modifier.height(54.dp),
        shape = RoundedCornerShape(10.dp)
    ) {
        Text(text, fontSize = 10.sp, color = White)
    }
}

private fun formatTime(ms: Long): String {
    val total = ms / 1000
    return "%02d:%02d".format(total / 60, total % 60)
}
