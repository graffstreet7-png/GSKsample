Coloca aquí el logo final como neveth_logo.png cuando lo aprobemos.
